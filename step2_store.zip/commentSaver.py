import mysql.connector
import json;

host = "127.0.0.1"
user = "root"
password ="root"
database = "digikala"

class CommentSaver:
    def __init__(self):
        self.db = None

    def __enter__(self):
        self.db = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.db is not None:
            self.db.close()

    def save_todb(self, values):

        self.delete_recs(values)

        insert_query = """
             INSERT INTO comments (id, product_id, title, body, created_at, rate, likes, dislikes, recommendation_status, seller_id, seller_title, seller_code, advantages, disadvantages)
             VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
             """
        # Use the with statement to manage the cursor
        with self.db.cursor() as cursor:
            try:
                cursor.executemany(insert_query, values)
                self.db.commit()
                print("Data saved successfully")
            except mysql.connector.Error as err:
                print(f"Error: {err}")
        # Close the database connection
        #self.db.close()

    def delete_recs(self, values):
        # Extract product_ids from values
        product_ids = [str(item[1]) for item in values]  # item[1] is the product_id
        print(product_ids)
        # Create the DELETE query
        delete_query = "DELETE FROM comments WHERE product_id IN (%s)" % ','.join(product_ids)
        # Execute the DELETE query
        with self.db.cursor() as cursor:
            try:
                cursor.execute(delete_query)
                self.db.commit()
                print("Data deleted successfully")
            except mysql.connector.Error as err:
                print(f"Error: {err}")
        #self.db.close()

    def close_connection(self):
        # Close the database connection
        self.db.close()

    # def save_todb_dataset(self, data):
    #     insert_query = """
    #         INSERT INTO comments_dataset (data)
    #         VALUES (%s,%s);
    #     """
    #     with self.db.cursor() as cursor:
    #         try:
    #             cursor.execute(insert_query, (data,))
    #             self.db.commit()
    #             print("SAVED Dataset successfully")
    #         except mysql.connector.Error as err:
    #             print(f"Error: {err}")

    # def save_todb_dataset(self, data_with_product_id):
    #     self.delete_recs2(data_with_product_id)
    #
    #     insert_query = """
    #         INSERT INTO comments_dataset (product_id, data)
    #         VALUES (%s, %s);
    #     """
    #     with self.db.cursor() as cursor:
    #         try:
    #             # Convert each dictionary to a JSON string
    #             data_with_product_id = [(pid, json.dumps(data)) for pid, data in data_with_product_id]
    #             cursor.executemany(insert_query, data_with_product_id)
    #             self.db.commit()
    #             print("SAVED Dataset successfully")
    #         except mysql.connector.Error as err:
    #             print(f"Error: {err}")

    def save_todb_dataset(self, output_list):
        self.delete_recs2(output_list)

        insert_query = """
            INSERT INTO comments_dataset (product_id, data,most_liked)
            VALUES (%s, %s, %s);
        """
        with self.db.cursor() as cursor:
            try:
                # Convert each dictionary to a JSON string

                # Convert each dictionary to a JSON string
                output_list = [(data['product_id'],
                                json.dumps({k: v for k, v in data.items() if k != 'most_liked_comment'}),
                                json.dumps(data['most_liked_comment'])) for data in output_list]
                cursor.executemany(insert_query, output_list)
                self.db.commit()
                print("SAVED Dataset successfully")
            except mysql.connector.Error as err:
                print(f"Error: {err}")

    def delete_recs2(self, output_list):
        # Extract product_ids from output_list
        product_ids = [str(data['product_id']) for data in output_list]

        # Create the DELETE query
        delete_query = "DELETE FROM comments_dataset WHERE product_id IN (%s)" % ','.join(product_ids)

        # Execute the DELETE query
        with self.db.cursor() as cursor:
            try:
                cursor.execute(delete_query)
                self.db.commit()
                print("Data deleted successfully")
            except mysql.connector.Error as err:
                print(f"Error: {err}")
