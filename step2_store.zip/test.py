import re

# Regex Cheat sheet : https://www.dataquest.io/blog/regex-cheatsheet/
# Regex python tester : https://pythex.org/
# re doc : https://docs.python.org/3/library/re.html

text = "apple" 
reg = "[a-z]" #the group of char a to c
m = m = re.search(r'(?<=-)\w+', 'spam-mohammad-ali')
print(m.group(0))
if re.match(reg, text): #Check if regex is correct
	print(text)
else:
  print("Not any match")