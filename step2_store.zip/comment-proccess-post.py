import pandas as pd
import mysql.connector
import re
import json

from commentSaver import CommentSaver


class CommentProccessPost:
    def __init__(self, host, user, password, database):
        self.host = host
        self.user = user
        self.password = password
        self.database = database

    def get_comments_data(self,product_ids):
        # Connect to the MySQL database
        conn = mysql.connector.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.database
        )
        query = "SELECT * FROM comments WHERE product_id IN ({})".format(','.join(['%s'] * len(product_ids)))

        # Load the data into a DataFrame using pandas
        df = pd.read_sql(query, con=conn, params=product_ids)
        conn.close()

        return df

    def analyze_likes(self, df):
        # Calculate total likes
        count_likes = df['likes'].count()

        # Calculate maximum likes
        max_likes = df['likes'].max()

        # Group by likes (0 and non-0) and calculate count and sum
        likes_grouped = df.groupby(df['likes'] == 0).agg({'likes': ['count', 'sum']})

        return count_likes, max_likes, likes_grouped

    def get_max_likes_row(self, df):
        # Find the row with the maximum number of likes
        max_likes_row = df[df['likes'] == df['likes'].max()]

        return max_likes_row

    def get_nonempty_advantages(self, df):
        # Filter rows where the length of 'advantages' is greater than 0
        nonempty_advantages = df[df['advantages'].str.len() > 5]
        # تبدیل مقادیر ستون advantages به فرمت مطلوب
        nonempty_advantages['advantages'] = nonempty_advantages['advantages'].apply(lambda x: ', '.join(eval(x)))

        # جدا کردن مقادیر رشته‌ای در لیست‌ها
        nonempty_advantages['advantages'] = nonempty_advantages['advantages'].str.split(', ')

        # حذف مقادیر تکراری و گروه‌بندی
        distinct_advantages = nonempty_advantages.explode('advantages').drop_duplicates(subset=['advantages'])

        # assume distinct_advantages is a Pandas DataFrame with a column named 'advantages'
        distinct_advantages["clean_advantages"] = distinct_advantages['advantages'].apply(lambda x: re.sub(r"[^\w\s']", '', x).strip())
        distinct_advantages['clean_advantages'] = distinct_advantages['clean_advantages'].apply(lambda x: re.sub(r'[^\w\s"]', '', x).strip())
        distinct_advantages["clean_advantages"].to_json("distinct_advantages2.json", orient="records", force_ascii=False)
        #print(distinct_advantages['clean_advantages'])
        return distinct_advantages['clean_advantages']

    def get_nonempty_disadvantages(self, df):
        # Filter rows where the length of 'disadvantages' is greater than 0
        nonempty_disadvantages = df[df['disadvantages'].str.len() > 5]
        return nonempty_disadvantages

    def calculate_average_rating(self,df):
        return df['rate'].mean().round(2)

    # Identify most common words
    def identify_most_common_words(self,df):
        return df['title'].str.word_tokenize().value_counts().tail(10).index

# Example usage:
# Initialize CommentAnalysis object
comment_analysis = CommentProccessPost(host='127.0.0.1', user='root', password='root', database='digikala')
# Get comments data from the MySQL database
product_ids = [806044]  # Replace with actual product IDs
comments_df = comment_analysis.get_comments_data(product_ids)
###################################################################################

# Analyze likes
count_likes, max_likes, likes_grouped = comment_analysis.analyze_likes(comments_df)
# Get the row with the maximum number of likes
max_likes_row = comment_analysis.get_max_likes_row(comments_df)

###################################################################################
# Get rows where length of 'advantages' is greater than 0
nonempty_advantages = comment_analysis.get_nonempty_advantages(comments_df)

# Get rows where length of 'disadvantages' is greater than 0
nonempty_disadvantages = comment_analysis.get_nonempty_disadvantages(comments_df)
###################################################################################
avg_rating = comment_analysis.calculate_average_rating(comments_df)



# # Print the results
print("Total Number of Likes in the Dataset:", count_likes)
print("Max Likes in the Dataset:", max_likes)
print(" average_rating:", avg_rating)
# print("\nLikes Grouped:")
likes_grouped.index = ['likes_nonZero', 'likes_zero']  # Rename the index for better readability
likes_grouped.columns = ['count', 'sum']  # Rename the columns for better readability
print(likes_grouped)
#
# # Print the entire row with the maximum number of likes
print("Row with Maximum Likes:")
#print(max_likes_row)
#
# print("\nRows with Non-empty Disadvantages:")
# print(nonempty_disadvantages)

# Print the results
#print("Rows with Non-empty Advantages:")
#print(nonempty_advantages)

print("###########################################################################################")
# Define the JSON object
output_json = {
    "likes_count": (str(count_likes)),
    "likes_max": (str(max_likes)),
    "likes_grouped": likes_grouped.to_dict(),
    "rate_avg": (str(avg_rating)),
}

# Assuming you have the product_id(s) in a list called product_ids



# Combine product_ids with the JSON data
data_with_product_id = [(product_id, output_json) for product_id in product_ids]

# Print the JSON object
print(json.dumps(data_with_product_id,indent=4))

with CommentSaver() as comment_saver:
    comment_saver.save_todb_dataset(data_with_product_id)

#print(output_json)




