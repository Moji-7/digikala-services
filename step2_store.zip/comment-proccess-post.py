import pandas as pd
import mysql.connector
import re
import json

from commentSaver import CommentSaver

class CommentProccessPost:
    def __init__(self, host, user, password, database):
        self.host = host
        self.user = user
        self.password = password
        self.database = database

    def get_comments_data(self,product_ids):
        # Connect to the MySQL database
        conn = mysql.connector.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.database
        )
        query = "SELECT * FROM comments WHERE product_id IN ({})".format(','.join(['%s'] * len(product_ids)))

        # Load the data into a DataFrame using pandas
        df = pd.read_sql(query, con=conn, params=product_ids)
        conn.close()

        return df

    def calculate_average_rating(self,df):
        return df['rate'].mean().round(2)

    def get_max_likes_row(self, df):
        # Find the row with the maximum number of likes
        max_likes_row = df[df['likes'] == df['likes'].max()]
        # تبدیل ردیف با بیشترین لایک به JSON
        max_likes_row_json = max_likes_row.to_json(orient='records')[1:-1]

        #print(max_likes_row_json)
        return max_likes_row_json

    def analyze_likes(self, df):
        # first group by product_IDs
        grouped_df = df.groupby('product_id')

        result_dict = {}
        for product_id, group_data in grouped_df:
            count_likes = group_data['likes'].count()
            max_likes = group_data['likes'].max()
            likes_grouped = group_data.groupby(df['likes'] == 0).agg({'likes': ['count', 'sum']})
            # more calculations
            rate_avg = comment_analysis.calculate_average_rating(group_data)
            most_liked_comment=comment_analysis.get_max_likes_row(group_data)
            result_dict[product_id] = {'count_likes': count_likes, 'max_likes': max_likes, 'likes_grouped': likes_grouped,
                                       'rate_avg':rate_avg,'most_liked_comment':most_liked_comment}

        return result_dict


# Example usage:
# Initialize CommentAnalysis object
comment_analysis = CommentProccessPost(host='127.0.0.1', user='root', password='root', database='digikala')
# Get comments data from the MySQL database
product_ids = [806044,197421,471187,471143]  # Replace with actual product IDs
comments_df = comment_analysis.get_comments_data(product_ids)
###################################################################################

# Analyze likes
result_dict = comment_analysis.analyze_likes(comments_df)

output_list = []
# Print the results for each product_id
for product_id, metrics in result_dict.items():
    count_likes = metrics['count_likes']
    max_likes = metrics['max_likes']
    rate_avg = metrics['rate_avg']
    most_liked_comment = metrics['most_liked_comment']
    likes_grouped = metrics['likes_grouped']
    likes_grouped.index = ['likes_nonZero', 'likes_zero']  # Rename the index for better readability
    likes_grouped.columns = ['count', 'sum']  # Rename the columns for better readability
    #print(most_liked_comment)
    # Define the JSON object
    output_json = {
        "product_id":product_id,
        "likes_count": str(count_likes),
        "likes_max": str(max_likes),
        "rate_avg": (str(rate_avg)),
        "likes_grouped": likes_grouped.to_dict(),
        "most_liked_comment":(most_liked_comment),
    }
    output_list.append(output_json)

print(json.dumps(output_list, indent=4))
#
with CommentSaver() as comment_saver:
    comment_saver.save_todb_dataset(output_list)