import json
import mysql.connector

class IncrediblesItem:
    def __init__(self, id, title_fa, title_en, url, brand, category, item_category2, item_category3, item_category4, item_category5, main_image_url, is_fast_shipping, is_ship_by_seller, min_price_in_last_month, seller_id, seller_title, seller_url, selling_price, rrp_price, order_limit, is_incredible, discount_percent, shipment_description, has_lead_time):
        self.id = id
        self.title_fa = title_fa
        self.title_en = title_en
        self.url = url
        self.brand = brand
        self.category = category
        self.item_category2 = item_category2
        self.item_category3 = item_category3
        self.item_category4 = item_category4
        self.item_category5 = item_category5
        self.main_image_url = main_image_url
        self.is_fast_shipping = is_fast_shipping
        self.is_ship_by_seller = is_ship_by_seller
        self.min_price_in_last_month = min_price_in_last_month
        self.seller_id = seller_id
        self.seller_title = seller_title
        self.seller_url = seller_url
        self.selling_price = selling_price
        self.rrp_price = rrp_price
        self.order_limit = order_limit
        self.is_incredible = is_incredible
        self.discount_percent = discount_percent
        self.shipment_description = shipment_description
        self.has_lead_time = has_lead_time

# Load the JSON data from the file
with open('incredibles.json', 'r', encoding='utf-8') as file:
    data = json.load(file)

# Connect to the MySQL database
conn = mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="root",
    database="digikala"
)
cursor = conn.cursor()

# Insert each item into the "incredibles" table
for item in data:
    incredibles_item = IncrediblesItem(**item)
    insert_query = """
         INSERT INTO incredibles (id, title_fa, title_en, url, brand, category, item_category2, item_category3, 
         item_category4, item_category5, main_image_url, is_fast_shipping, is_ship_by_seller, min_price_in_last_month, 
         seller_id, seller_title, seller_url, selling_price, rrp_price, order_limit, is_incredible, discount_percent, 
         shipment_description, has_lead_time) 
         VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s)
         """
    cursor.execute(insert_query, (incredibles_item.id, incredibles_item.title_fa, incredibles_item.title_en,
                                  incredibles_item.url, incredibles_item.brand, incredibles_item.category,
                                  incredibles_item.item_category2, incredibles_item.item_category3,
                                  incredibles_item.item_category4, incredibles_item.item_category5,
                                  incredibles_item.main_image_url, incredibles_item.is_fast_shipping,
                                  incredibles_item.is_ship_by_seller, incredibles_item.min_price_in_last_month,
                                  incredibles_item.seller_id, incredibles_item.seller_title,
                                  incredibles_item.seller_url, incredibles_item.selling_price,
                                  incredibles_item.rrp_price, incredibles_item.order_limit,
                                  incredibles_item.is_incredible, incredibles_item.discount_percent,
                                  incredibles_item.shipment_description, incredibles_item.has_lead_time))
conn.commit()
conn.close()
