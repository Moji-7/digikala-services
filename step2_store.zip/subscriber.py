# import the required libraries
import redis
import json

from OrderSaver import OrderSaver

import dill as pickle
import multiprocessing

# define the class
class SubscriberMultiprocess:
    # define the constructor
    def __init__(self):
        print("ali")
        # connect to Redis server
        self.r = redis.Redis(host='127.0.0.1', port=6379, db=0)
        self.p = self.r.pubsub()

        self.keep_listening = True
        self.order_saver = OrderSaver(host="127.0.0.1", user="root", password="root", database="digikala")
        # create a pool of processes
        self.pool = multiprocessing.Pool() # you can specify the number of processes if you want

    def subscribe_to_channel(self, channel_name):
        # Subscribe to the specified channel
        self.p.subscribe(channel_name)

    # define the method that saves the orders to Redis
    def save_orders_to_redis(self, orders):
        print(orders)
        args = []
        for order in (orders):
            order_key = f"order:{order['id']}"
            args.extend([order_key, ".", json.dumps(order)])
        self.r.execute_command("JSON.MSET", *args)

    # define the method that saves the orders to MySQL
    def save_to_mysql(self, orders):
        # use the save_orders method from the class to save the orders to MySQL
        self.order_saver.save_orders(orders)


    def listen_for_messages(self):
        # Listen for messages from the channel using a loop
        while self.keep_listening:
            message = self.p.get_message()
            if message:
                # Check if the message is a data message
                if message["type"] == "message":
                    # Get the data from the message
                    data = message["data"]
                    # Parse the data as a JSON string
                    orders = json.loads(data)
                    #print(orders)
                    # submit the tasks to the pool asynchronously and get the result objects
                    result1 = self.pool.apply_async(self.save_orders_to_redis, args=(orders,))
                    result2 = self.pool.apply_async(self.save_to_mysql, args=(orders,))
                    # get the results and handle any exceptions
                    try:
                        result1.get()
                        result2.get()
                    except Exception as e:
                        print(e)
        # close the pool and wait for the tasks to complete
        self.pool.close()
        self.pool.join()



# check for top-level environment
if __name__ == '__main__':
    # create an instance
    subscriberMultiprocess = SubscriberMultiprocess()
    # subscribe to the "orders" channel
    subscriberMultiprocess.subscribe_to_channel("orders")
    # start listening for messages in a separate thread or process
    subscriberMultiprocess.listen_for_messages()
