"# digikala-subscriber" 
