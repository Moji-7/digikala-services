import json

import mysql.connector

# Assuming 'data' is the list of dictionaries containing the product information

# Connect to the MySQL database
conn = mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="root",
    database="digikala"
)
class ProductsItem:
    def __init__(self, id, product_id, seller_id, seller_title, seller_url, selling_price, rrp_price, order_limit, is_incredible, discount_percent):
        self.id = id
        self.product_id = product_id
        self.seller_id = seller_id
        self.seller_title = seller_title
        self.seller_url = seller_url
        self.selling_price = selling_price
        self.rrp_price = rrp_price
        self.order_limit = order_limit
        self.is_incredible = is_incredible
        self.discount_percent = discount_percent

cursor = conn.cursor()
# Load the JSON data from the file
with open('product.json', 'r', encoding='utf-8') as file:
    data = json.load(file)
for item in data:
    products_item = ProductsItem(**item)
    insert_query = """
         INSERT INTO products (id,product_id, seller_id, seller_title, seller_url, selling_price, rrp_price, order_limit, is_incredible, discount_percent) 
         VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
         """
    cursor.execute(insert_query, (products_item.id,products_item.product_id ,products_item.seller_id, products_item.seller_title, products_item.seller_url, products_item.selling_price, products_item.rrp_price, products_item.order_limit, products_item.is_incredible, products_item.discount_percent))

conn.commit()
conn.close()
