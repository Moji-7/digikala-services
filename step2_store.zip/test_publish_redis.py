import redis
import json

def publish_orders_to_redis_channel(host='localhost', port=6379, db=0):
    # Connect to Redis server
    r = redis.Redis(host=host, port=port, db=db)
    order_items = [
        {'id': 999999999, 'payable_price': 9006900},
        {'id': 777777777, 'payable_price': 8215400}
    ]
    # publish all JSON array to Redis
    order_items_json = json.dumps(order_items)
    r.publish("orders", order_items_json)


# Call the method to publish the orders to the Redis channel
publish_orders_to_redis_channel()
