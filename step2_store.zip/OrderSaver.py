import mysql.connector
import json


class OrderSaver:
    def __init__(self, host, user, password, database):
        # Connect to the MySQL database
        self.db = mysql.connector.connect(
            host="127.0.0.1",
            user="root",
            password="root",
            database="digikala"
        )
        self.cursor = self.db.cursor()
    def save_orders(self,orders):
        args = []
        for order in orders:
            # use the order id as the key
            order_key = f"{order['id']}"
            print(order_key)
            # convert the order dictionary to a JSON string and append it to the args list
            args.append((order_key, json.dumps(order)))
        # Bulk insert multiple orders into the MySQL database
        try:
            sql = "INSERT INTO orders (order_id, order_content) VALUES (%s, %s)"
            self.cursor.executemany(sql, args)
            self.db.commit()
            print("Orders saved successfully")
        except mysql.connector.Error as err:
            print(f"Error: {err}")


