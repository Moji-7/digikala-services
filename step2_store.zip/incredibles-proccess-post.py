


import subprocess
import time
import random
import re

class DatabaseLoader:
    def __init__(self, database, table):
        self.database = database
        self.table = table

    def get_random_record(self):
        # Get a random record from the table and extract the values
        query = f"Select first 20 acceptorid From {self.table}"
        echo_command = f'echo "{query}" | dbaccess -e {self.database}'

        # Run the command and capture the output
        result = subprocess.run(echo_command, shell=True, capture_output=True, check=True)
        values = []
        for line in lines[index + 1:]:
            if line.strip():
                values.append(line)
            else:
                break

        # Decode the output
        output = result.stdout.decode()

        # Split the output into lines
        lines = output.split('\n')

        # Find the index of the line containing 'acceptorid'
        index = lines.index('acceptorid')

        # Get the lines after 'acceptorid' and filter out empty lines
        values = [line for line in lines[index + 1:] if line.strip()]

        print(values)

        # Get the lines that contain the values
        value_lines = lines[4:-4]  # Skip the header and footer lines

        # Define a regular expression pattern to match the values
        pattern = r"\s*(\w+)\s+(-?\d+|##ALL##|-1|[A-Z])"

        # Loop through the value lines and extract the values
        values = []
        for line in value_lines:
            # Search for the pattern in the line
            match = re.search(pattern, line)
            if match:
                # Get the value from the second group of the match
                value = match.group(2)
                # Append the value to the list
                values.append(value)

        # Print the extracted values
        print(values)
        # Get the number of columns in the table
        num_columns = len(values) // 2  # Assuming you selected two rows

        # Loop through the values and group them by rows
        rows = []
        for i in range(0, len(values), num_columns):
            # Get a slice of values for each row
            row = values[i:i + num_columns]
            # Append the row to the list
            rows.append(row)

        # Print the rows
        print(rows)
        # Define the indices of the values you want to get
        indices = [1, 5, 7]  # 2nd, 6th, 8th

        # Define the keys for the dictionaries
        keys = ["2nd", "6th", "8th"]/

        # Loop through the rows and get the values by indices
        result2 = []
        for row in rows:
            # Create an empty dictionary for each row
            d = {}
            # Loop through the indices and keys
            for i, k in zip(indices, keys):
                # Get the value from the row by index
                value = row[i]
                # Assign the value to the dictionary by key
                d[k] = value
            # Append the dictionary to the result list
            result2.append(d)

        # Print the result
        print(result2)

if __name__ == "__main__":
    loader = DatabaseLoader("emaddb", "limitation")
    n = 1  # Number of times to run the query
    start_time = time.time()
    while time.time() - start_time < 1:
        for _ in range(n):
            # Get a random record and assign the variables
            loader.get_random_record()
        time.sleep(1)
