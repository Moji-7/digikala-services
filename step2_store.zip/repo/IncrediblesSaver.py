import mysql.connector
import json
import os

# Get the environment variables
# host = os.getenv("HOST")
# user = os.getenv("USER")
# password = os.getenv("PASSWORD")
# database = os.getenv("DATABASE")
host = "127.0.0.1"
user = "root"
password ="root"
database = "digikala"

class IncrediblesSaver:
    def __init__(self):
        self.db = None

    def __enter__(self):
        self.db = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.db is not None:
            self.db.close()

    def save_todb(self, values):
        # Construct the query for the DELETE statement
        #delete_query = "DELETE FROM incredibles WHERE id IN (%s)" % ','.join(['%s'] * len(values))

        insert_query = """
        INSERT INTO incredibles(id,title_fa,title_en,url,brand,category,item_category2,item_category3,
        item_category4,item_category5,main_image_url,is_fast_shipping,is_ship_by_seller,min_price_in_last_month,
        seller_id,seller_title,seller_url,selling_price,rrp_price,order_limit,is_incredible,discount_percent,
        shipment_description,has_lead_time)
        VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """
        # Use the with statement to manage the cursor
        with self.db.cursor() as cursor:
            try:
                # Delete specific records based on id values
                #cursor.execute(delete_query, tuple([v[0] for v in values]))
                # Execute the INSERT query with the values using the executemany method
                cursor.executemany(insert_query, values)
                self.db.commit()
                print("Data saved successfully")
            except mysql.connector.Error as err:
                print(f"Error: {err}")

        # Close the database connection
        #self.db.close()
