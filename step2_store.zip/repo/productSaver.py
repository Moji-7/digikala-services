import mysql.connector

host = "127.0.0.1"
user = "root"
password ="root"
database = "digikala"

class ProductSaver:
    def __init__(self):
        self.db = None

    def __enter__(self):
        self.db = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.db is not None:
            self.db.close()

    def save_todb(self, values):

        self.delete_recs(values)

        insert_query = """
             INSERT INTO products (id,product_id, seller_id, seller_title, seller_url, selling_price, rrp_price, order_limit, is_incredible, discount_percent)
             VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
             """
        # Use the with statement to manage the cursor
        with self.db.cursor() as cursor:
            try:
                cursor.executemany(insert_query, values)
                self.db.commit()
                print("Data saved successfully")
            except mysql.connector.Error as err:
                print(f"Error: {err}")
        # Close the database connection
        #self.db.close()

    def delete_recs(self, values):
        # Extract product_ids from values
        product_ids = [str(item[1]) for item in values]  # item[1] is the product_id
        print(product_ids)
        # Create the DELETE query
        delete_query = "DELETE FROM products WHERE product_id IN (%s)" % ','.join(product_ids)
        # Execute the DELETE query
        with self.db.cursor() as cursor:
            try:
                cursor.execute(delete_query)
                self.db.commit()
                print("Data deleted successfully")
            except mysql.connector.Error as err:
                print(f"Error: {err}")
        #self.db.close()

    def close_connection(self):
        # Close the database connection
        self.db.close()
