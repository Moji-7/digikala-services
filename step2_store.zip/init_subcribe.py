import redis
import json

from OrderSaver import OrderSaver
from commentSaver import CommentSaver
from repo.IncrediblesSaver import IncrediblesSaver
from repo.productSaver import ProductSaver


class RedisSubscriber:
    def __init__(self, host='127.0.0.1', port=6379, db=0):
        # create an instance of the OrderSaver class
        # self.order_saver = OrderSaver.save_order();
        # Connect to Redis server
        self.r = redis.Redis(host=host, port=port, db=db)
        # Create a pubsub object
        self.p = self.r.pubsub()
        # Flag to indicate whether to continue listening for messages
        self.keep_listening = True
        # Create an instance of the IncrediblesSaver class
        self.incredibles_saver = IncrediblesSaver()
        self.Product_saver = ProductSaver()
        self.comment_saver = CommentSaver()

    def subscribe_to_channel(self, channel_name):
        # Subscribe to the specified channel
        self.p.subscribe(channel_name)

    def listen_for_messages(self):
        # Listen for messages from the channel using a loop
        while self.keep_listening:
            message = self.p.get_message()
            if message:
                # Check if the message is a data message
                if message["type"] == "message":
                    # Get the data from the message
                    data = message["data"]
                    # Parse the data as a JSON string
                    orders = json.loads(data)
                    # Process the orders data (example: print the orders)
                    print(orders)
                    # 1 to Redis
                    self.save_orders_to_redis(orders)
                    # 2 to mysql
                    # Create an instance of the OrderSaver class
                    order_saver = OrderSaver(host="127.0.0.1", user="root", password="root", database="digikala")
                    order_saver.save_orders(orders)

    def listen_for_messages2(self):
        # Listen for messages from the channel using a loop
        while self.keep_listening:
            message = self.p.get_message()
            if message:
                if message["type"] == "message":
                    data = message["data"]
                    result = json.loads(data)
                    print(json.dumps(result, ensure_ascii=False))
                    values = [
                        (
                            item['id'], item['title_fa'], item['title_en'], item['url'], item['brand'],
                            item.get('category', ''), item.get('item_category2', ''), item.get('item_category3', ''),
                            item.get('item_category4', ''), item.get('item_category5', ''),
                            item.get('main_image_url', ''),
                            item.get('is_fast_shipping', ''), item.get('is_ship_by_seller', ''),
                            item.get('min_price_in_last_month', ''),
                            item.get('seller_id', ''), item.get('seller_title', ''), item.get('seller_url', ''),
                            item.get('selling_price', ''), item.get('rrp_price', ''), item.get('order_limit', ''),
                            item.get('is_incredible', ''), item.get('discount_percent', ''),
                            item.get('shipment_description', ''),
                            item.get('has_lead_time', '')
                        ) for item in result
                    ]
                    # Call the save_todb method with the updated values list
                    with IncrediblesSaver() as incredibles_saver:
                        incredibles_saver.save_todb(values)

    def listen_for_messages3(self):
        print("ali")
        # Listen for messages from the channel using a loop
        while self.keep_listening:
            message = self.p.get_message()
            if message:
                if message["type"] == "message":
                    data = message["data"]
                    result = json.loads(data)
                    #print(result)
                    #print(json.dumps(result, ensure_ascii=False))
                    values = [
                        (
                            item['id'], item['product_id'], item['seller_id'], item['seller_title'], item['seller_url'],
                            item['selling_price'],item['rrp_price'],item['order_limit'], item['is_incredible'], item['discount_percent'],
                        )
                        for item in result
                    ]
                    #Call the save_todb method with the updated values list
                    #self.Product_saver.save_todb(values)
                    with ProductSaver() as product_saver:
                        product_saver.save_todb(values)
    def listen_for_messages4(self):
        print("ali")
        # Listen for messages from the channel using a loop
        while self.keep_listening:
            message = self.p.get_message()
            if message:
                if message["type"] == "message":
                    data = message["data"]
                    result = json.loads(data)
                    print(result)
                    #print(json.dumps(result, ensure_ascii=False))
                    values = [
                        (
                            item['id'], item['product_id'], item['title'], item['body'], item['created_at'],
                            item['rate'], item['likes'], item['dislikes'], item['recommendation_status'],
                            item['seller_id'], item['seller_title'], item['seller_code'],
                            json.dumps(item['advantages'], ensure_ascii=False), json.dumps(item['disadvantages'], ensure_ascii=False)
                        )
                        for item in result
                    ]
                    #Call the save_todb method with the updated values list
                    #self.Product_saver.save_todb(values)
                    with CommentSaver() as comment_saver:
                        comment_saver.save_todb(values)



    # 1 to Redis
# self.save_orders_to_redis(orders)
# 2 to mysql
# Create an instance of the OrderSaver class
# order_saver = IncrediblesSaver(host="127.0.0.1", user="root", password="root", database="digikala")
# order_saver.save_todb(orders)

    def save_orders_to_redis(self, orders):
        print(orders)
        args = []
        for order in (orders):
            # use the order id as the key
            order_key = f"order:{order['id']}"
            # append the key and convert the order dictionary to a JSON string, to the arguments list
            args.extend([order_key, ".", json.dumps(order)])

        # store the orders as JSON objects in Redis using JSON.MSET
        self.r.execute_command("JSON.MSET", *args)
        # self.r.execute_command("JSON.SET", order_key, ".", order_json)

    def stop_listening(self):
        # Set the flag to stop listening
        self.keep_listening = False


# Create an instance of the RedisSubscriber class
subscriber = RedisSubscriber()

# Subscribe to the "orders" channel
# subscriber.subscribe_to_channel("orders")
# Start listening for messages in a separate thread or process
# subscriber.listen_for_messages()


# Subscribe to the "orders" channel
# subscriber.subscribe_to_channel("incredibles")
# subscriber.listen_for_messages2()
# subscriber.subscribe_to_channel("product")
# subscriber.listen_for_messages3()
subscriber.subscribe_to_channel("comment")
subscriber.listen_for_messages4()
